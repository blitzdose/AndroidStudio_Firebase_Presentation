package com.example.tasks;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {


   /* private EditText newTask;
    private LinearLayout taskBlock;
    private LinearLayout buttonBlock;
    private ScrollView scroll;*/

    


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        /*newTask=findViewById(R.id.newTask);
        taskBlock=findViewById(R.id.taskBlock);
        buttonBlock=findViewById(R.id.buttonBlock);
        scroll=findViewById(R.id.scroll);*/


        /*newTask.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                newTask.setText("");
                newTask.setTextColor(getResources().getColor(R.color.black));
            }
        });*/

    }

    public void showOldTasks(){
        /*
        taskBlock.removeAllViews();
        buttonBlock.removeAllViews();

        count=getSharedPreferences("Tasks", MODE_PRIVATE).getInt("Quantity",0);
        for (int i=0; i<count; i++){
            addTask(getSharedPreferences("Tasks", MODE_PRIVATE).getString(Integer.toString(i),""), i);
        }*/
    }

    public void addTask(String task, int taskNumber){

        if (!task.isEmpty()) {

            /*Button icon= new Button(MainActivity.this);
            icon.setLayoutParams(new ViewGroup.LayoutParams(130, 140));
            icon.setBackground(this.getResources().getDrawable(R.mipmap.pfeil_foreground));
            icon.setGravity(Gravity.CENTER_VERTICAL);
            taskTextLayout.addView(icon);*/

            /*Button taskDelete = new Button(MainActivity.this);
            taskDelete.setText("Del");
            taskDelete.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, 168));
            taskDelete.setTextSize(15);
            taskDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SharedPreferences.Editor editor = getSharedPreferences("Tasks", MODE_PRIVATE).edit();
                    editor.remove(Integer.toString(taskNumber));
                    editor.apply();

                    showOldTasks();

                }
            });

            taskBlock.addView(taskTextLayout);
            buttonBlock.addView(taskDelete);
            scroll.fullScroll((ScrollView.FOCUS_DOWN));*/
        }

    }
}