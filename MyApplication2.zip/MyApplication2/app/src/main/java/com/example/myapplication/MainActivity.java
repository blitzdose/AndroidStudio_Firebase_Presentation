package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button add;
    private EditText newTask;
    private LinearLayout taskBlock;
    private LinearLayout buttonBlock;
    private ScrollView scroll;

    private  int count;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Connect Java-activity with XML-layout
        setContentView(R.layout.activity_main);


        //Connect XML-buttons with Java-entitys
        add=findViewById(R.id.add);
        newTask=findViewById(R.id.newTask);
        taskBlock=findViewById(R.id.taskBlock);
        buttonBlock=findViewById(R.id.buttonBlock);
        scroll=findViewById(R.id.scroll);




        showOldTasks();


        //Configurate or add some usages of elemenst
        scroll.fullScroll((ScrollView.FOCUS_DOWN));

        newTask.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                newTask.setText("");
                newTask.setTextColor(getResources().getColor(R.color.black));
            }
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (newTask.getText()!=null){

                    addTask(newTask.getText().toString(), count);


                    //Save tasks locally
                    SharedPreferences.Editor editor= getSharedPreferences("Tasks", MODE_PRIVATE).edit();
                    editor.putString(Integer.toString(count), String.valueOf(newTask.getText()));
                    count=count+1;
                    editor.putInt("Quantity",count);
                    editor.apply();

                }

                newTask.setText("");


            }
        });

    }

    public void showOldTasks(){
        //Display tasks from old sessions
        taskBlock.removeAllViews();
        buttonBlock.removeAllViews();

        count=getSharedPreferences("Tasks", MODE_PRIVATE).getInt("Quantity",0);
        for (int i=0; i<count; i++){
            addTask(getSharedPreferences("Tasks", MODE_PRIVATE).getString(Integer.toString(i),""), i);
        }
    }

    public void addTask(String task, int taskNumber){
        //Add and save new tasks, display it with icon and delete-button

        if (!task.isEmpty()) {

            LinearLayout taskTextLayout = new LinearLayout(MainActivity.this);
            taskTextLayout.setOrientation(LinearLayout.HORIZONTAL);

            Button icon= new Button(MainActivity.this);
            icon.setLayoutParams(new ViewGroup.LayoutParams(130, 140));
            icon.setBackground(this.getResources().getDrawable(R.mipmap.pfeil_foreground));
            icon.setGravity(Gravity.CENTER_VERTICAL);
            taskTextLayout.addView(icon);

            TextView newTaskText = new TextView(MainActivity.this);
            newTaskText.setTextSize(20);
            newTaskText.setText(task);
            newTaskText.setGravity(Gravity.CENTER_VERTICAL);
            newTaskText.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, 168));
            taskTextLayout.addView(newTaskText);




            Button taskDelete = new Button(MainActivity.this);
            taskDelete.setText("Del");
            taskDelete.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, 168));
            taskDelete.setTextSize(15);
            taskDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SharedPreferences.Editor editor = getSharedPreferences("Tasks", MODE_PRIVATE).edit();
                    editor.remove(Integer.toString(taskNumber));
                    editor.apply();

                    showOldTasks();

                }
            });


            taskBlock.addView(taskTextLayout);
            buttonBlock.addView(taskDelete);
            scroll.fullScroll((ScrollView.FOCUS_DOWN));
        }

    }
}